/*

		Name: Anna Opgrande 
		Date: 01/23/24
		Class: CptS 121 
		Programming Assignment One 

*/
#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include<math.h>

main(void) 
{
	double series_resistance = 0, seriesR1 = 0, seriesR2 = 0, seriesR3 = 0,total_sales_tax = 0, sales_tax_rate = 0, item_cost = 0,
		volume_pyramid = 0, lengthOne = 0, heightOne = 0, widthOne = 0,distanceFormula = 0, xOne = 0, xTwo= 0,
		yOne = 0, yTwo = 0, shift= 0, equationZ = 0,equationX = 0, equationY = 0, generalEquation = 0, PI = 3.142, r1PlusOne = 0, r2PlusOne = 0,
		differenceX = 0, differenceY = 0, YplusX = 0, equationYDivided = 0, equationXDivided = 0; //Allocates memory space for floating point values 

	int  parallelR2 = 0, parallelR3 = 0, parallelR1 = 0, equationA = 0, parallel_resistance = 0, modulusA = 0;

	char plaintext_character = 0, encoded_character = 0;

	printf("Enter resistance one to find the series resistance: ");  //prompts user for resitance 1
	scanf("%d",&seriesR1); 

	printf("Enter resistance two to find the series resistance: "); //prompts user for resistance 2
	scanf("%d",&seriesR2);

	printf("Enter resistance three to find the series resistance: ");  //prompts user for resistance 3
	scanf("%d",&seriesR3);

	series_resistance = seriesR1 + seriesR2 + seriesR3;                                // adds the resitances together 

	printf("The series resistance is: %d\n",series_resistance);     // prints what the series resistance si 
	 
	printf("Enter the the sales tax rate to find the sales tax : ");  // prompts user for sales tax rate
	scanf("%lf",&sales_tax_rate);									// assigns number to sales_tax_rate

	printf("Enter the item cost to find the sales tax: ");            // prompts iser for the cost of the item 
	scanf("%lf",&item_cost);										// assigns number to item_cost 

	total_sales_tax = sales_tax_rate * item_cost;                      // muliplies the tax rate and item cost to find the sales tax 

	printf("The total sales tax is: %lf\n",total_sales_tax);        // prints the total sales tax 
	
	printf("Enter the length of the pyramid in order to find the volume: "); // prompts user for the lenght of the pyramid
	scanf("%lf", &lengthOne);												// assigns number to lengthOne

	printf("Enter the width of the pyramid to find the volume: ");   // prompts user for the width of the pyramid 
	scanf("%lf", &widthOne);											// assigns number to widthOne

	printf("Enter the height of the pyramid in order to find the volume: ");	// prompts user for height to find the volume 
	scanf("%lf", &heightOne);													// assigns user to heightOne 

	volume_pyramid = lengthOne * widthOne * heightOne / 3;						// equation for the volume of the pyramid 

	printf("The volume of the right pyramid is: %lf\n", volume_pyramid);		// prints the volume of the pyramid 

	printf("Enter a value of resistance to find parallel resistance: ");        // prompts user for resistance 
	scanf("%d", &parallelR1);													// assigns resistance to parallelR2 

	printf("Enter a second value of resistance to find parallel resistance: ");  // prompts user for another resistance value 
	scanf("%d", &parallelR2);													// assigns number to parallelR2 

	printf("Enter a third value of resistance to find parallel resistance: ");  // prompts user for third resistance value 
	scanf("%d", &parallelR3);													// assigns number to parallelR3 
	
	r1PlusOne = parallelR1 + 1;
	r2PlusOne = parallelR2 + 1; 

	parallel_resistance = 1 /(1/ r1PlusOne /r2PlusOne/ parallelR3); // equation for parallel resistance 

	printf("The parallel resistance is: %d\n",parallel_resistance);  // prints the parallel resistance 
	
	printf("Enter a character: ");                             // prompts user for a character
	scanf(" %c",&plaintext_character);                  // reads in the character 

	printf("Enter a shift value:");                     // prompts user for shift value 
	scanf("%d",&shift); 

	encoded_character = (plaintext_character - 'a') + 'A' - shift;  // equation for encoded character 
	printf("Encoded Character %c\n",encoded_character);             // prints the answer to the equation 
	 
	printf("Enter the value of X one: ");                            // prompt user for x value 
	scanf("%lf", &xOne);                                             // reads in the value 

	printf("Enter the value of Y one: ");                            // prompts user for y value 
	scanf("%lf", &yOne);                                             // reads in value 

	printf("Enter the value of X two: ");                             // prompts user for x value 
	scanf("%lf", &xTwo);                                              // reads on x value 

	printf("Enter the value of Y two: ");                             // prompts user for y value 
	scanf("%lf", &yTwo);                                              // reads in the y value 

	differenceX = (xOne - xTwo)*(xOne - xTwo);                         // equations for distance formula because it wasn't working when
																		// I did it as one equation 
	
	differenceY = (yOne - yTwo) * (yOne - yTwo); 

	YplusX = differenceX + differenceY;

	distanceFormula = sqrt(YplusX); 
	
	//distanceFormula = (pow(xOne - xTwo, 2) + pow(yOne - yTwo, 2)); 

	printf("The distance between the points is: %lf\n",distanceFormula);    // prints the distance 
	
	printf("For the general equation, enter an integer value for a: ");      // prompts user for a value 
	scanf("%d", &equationA);                                                 // reads in value 

	printf("For the general equation, enter a value for z: "); 
	scanf("%lf", &equationZ); 

	printf("For the general equation, enter a value for x: ");
	scanf("%lf", &equationX);

	printf("For the general equation, enter a value for y: ");
	scanf("%lf", &equationY); 

	modulusA = equationA % 2; 
	equationYDivided = equationY / 3 / 17;
	equationXDivided = equationX / (modulusA) ; 

	generalEquation = (equationYDivided) - 12 + (equationXDivided) + PI;


	printf("The answer for the general equation is: %lf", generalEquation); 

	return 0; 
}