/*

		Name: Anna Opgrande 
		Date: 02/05/24
		Class: CptS 121 
		Programming Assignment 3

		This programs reads the id, gpa, age and class standing from the file "input.dat". It uses the functions "read_integer" and "read_double"
		to read in the numbers. It then uses the information to call find the sum, mean, devitation, variance, the standard deviation along the largest number and the smallest number. 
		It then prints these results in the "output.dat" file. 
		

*/
#define _CRT_SECURE_NO_WARNINGS                                        // used to ignore warnings for scanf and printf 
#include <stdio.h>   
#include<math.h>
#include"Equations.h"                                                // allows you to call functions from the "Equations.h" file 

int main(void){                                                      // starting point of all c programs 
	
	FILE* input_stream =NULL,*output_stream = NULL;                   

	input_stream = fopen("input.dat", "r");                                            // opens the "input.dat" to read from the infile 

	output_stream = fopen("output.dat", "w");                                         // opens the "output.dat" to read from the infile 

	int student1ID = read_integer(input_stream);                                    // reads the ID for student one from the infile 
	  
	double student1GPA = read_double(input_stream);                                 // reads the GPA for student one from the infile

	int student1Class = read_integer(input_stream);                                  // reads the class of student one from the infile 

	double student1Age = read_double(input_stream);                                   // reads the age of student one from the infile 

	int student2ID = read_integer(input_stream);                                      // reads the ID of student two from the infile 

	double student2GPA = read_double(input_stream);                                   // reads the GPA of student two from the infile 
	 
	int student2Class = read_integer(input_stream);                                    // reads the class of student two from the infile 

	double student2Age = read_double(input_stream);                                   // reads the age of student two from the infile 

	int student3ID = read_integer(input_stream);                                      // reads the ID of student three from the infile 

	double student3GPA = read_double(input_stream);                                   // reads the GPA of student three from the infile 

	int student3Class = read_integer(input_stream);                                   // reads the class of student three from the infile 

	double student3Age = read_double(input_stream);                                   // reads the age of student three from the infile 

	int student4ID = read_integer(input_stream);                                      // reads the ID of student four from the infile 

	double student4GPA = read_double(input_stream);                                    // reads the GPA of student four from the infile 

	int student4Class = read_integer(input_stream);                                    // reads the class of student four from the infile 

	double student4Age = read_double(input_stream);                                    // reads the age of student four from the infile 

	int student5ID = read_integer(input_stream);                                       // reads the ID of student five from the infile 

	double student5GPA = read_double(input_stream);                                    // reads the GPA of student five from the infile 

	int student5Class = read_integer(input_stream);                                    // reads the class of student 5 from the infile 

	double student5Age = read_double(input_stream);                                     // reads the age of student 5 from the infile 

	double sumGPA = calculate_sum(student1GPA, student2GPA, student3GPA, student4GPA, student5GPA);                // calls the function calculate_sum to find the sum of GPAs

	double sumClass =calculate_sum(student1Class, student2Class, student3Class, student4Class, student5Class);    // calls the function calculate_sum to find the sum of the classes

	double sumAge = calculate_sum(student1Age, student2Age, student3Age, student4Age, student5Age);                 // calls the function calculate_sum to find the sum of ages 

	double meanGPA = calculate_mean(sumGPA,5);                                              // calls the function calculate_mean to find the mean of the GPAs 

	double meanClass = calculate_mean(sumClass,5);                                          // calls the function calculate_mean to find the mean of the classes 

	double meanAge = calculate_mean(sumAge,5);                                              // calls the function calculate_mean to find the mean of the ages 

	double student1Deviation = calculate_deviation(student1GPA,meanGPA);                    // calls the function calculate_deviation to finds the deviation for student 1 GPA

	double student2Deviation = calculate_deviation(student2GPA, meanGPA);                   // calls the function calculate_deviation to finds the deviation for student 2 GPA

	double student3Deviation = calculate_deviation(student3GPA, meanGPA);                   // calls the function calculate_deviation to finds the deviation for student 3 GPA

	double student4Deviation = calculate_deviation(student4GPA, meanGPA);                   // calls the function calculate_deviation to finds the deviation for student 4 GPA

	double student5Deviation = calculate_deviation(student5GPA, meanGPA);                   // calls the function calculate_deviation to finds the deviation for student 5 GPA

	double varianceGPA = calculate_variance(student1Deviation, student2Deviation, student3Deviation, student4Deviation, student5Deviation, 5);         // calls the function caluclate_variance to find the variance of GPAs
	
	double standardDeviation = calculate_standard_deviation(varianceGPA);                  // calls the function calculate_standard_deviation 

	double gpaMin = find_min(student1GPA, student2GPA, student3GPA, student4GPA, student5GPA);      // calls the function find_min to find the minimum GPA 

	double gpaMax = find_max(student1GPA, student2GPA, student3GPA, student4GPA, student5GPA);     // calls the function find_mac to fidn the maximum GPA 

	print_double(output_stream,meanGPA);                                                           // calls the function print_double to pirnt the mean GPA in the outfile

	print_double(output_stream, meanClass);                                                        // calls the function print_double to print the mean Class in the outfile

	print_double(output_stream, meanAge);                                                          // calls the function print_double to print the meanAge in the outfile

	print_double(output_stream,standardDeviation);                                                 // calls the function print_double to print the standard deviation in the outfile 

	print_double(output_stream,gpaMin);                                                            // calls the function print_double to print the gpaMin in the outfile  

	print_double(output_stream,gpaMax);                                                            // calls the function print_double to print the gpaMax in the outfile

	fclose(input_stream); 

	fclose(output_stream);

	return 0; 
}
