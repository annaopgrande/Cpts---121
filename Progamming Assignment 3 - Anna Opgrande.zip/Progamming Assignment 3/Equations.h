
#define _CRT_SECURE_NO_WARNINGS_ 
#include <stdio.h>
#include<math.h>

double read_double(FILE* input_stream){

	double Number; 

	fscanf(input_stream,"%lf",&Number); 

	return Number;

}

/*

Function: read_double 
Date Created: 02/07/24
Date Last Modified: 02/08/24

Description: Reads a line from the input.dat and allocates memory and labels number

Input Parameters: FIlE* input_stream
Returns: The number read from the infile 
Preconditions: None 
Postconditions: None

*/


int read_integer(FILE* input_stream) {

	int Number; 

	fscanf(input_stream,"%d",&Number); 

	return Number; 
}
/*

Function: read_integer
Date Created: 02/07/24
Date Last Modified: 02/08/24

Description: Reads a line from the input.dat and allocates memory and labels number

Input Parameters: FIlE* input_stream
Returns: The number read from the infile
Preconditions: None
Postconditions: None

*/

double calculate_sum(double number1, double number2, double number3, double number4, double number5) {

	double sum; 

	sum = number1 + number2 + number3 + number4 + number5; 

	return sum; 


}
/*

Function: calculate_sum
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: Adds five double numbers together 

Input Parameters: double number1, double number2, double number3, double number4, double number5
Returns: The sum 
Preconditions: None
Postconditions: None

*/


double calculate_mean(double sum, int number) {

	double mean; 

	mean = sum / number; 
	
	return mean; 
}
/*

Function: calculate_mean
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: takes the sum from the calculate_sum function and divides it by another integer to find the mean 
Input Parameters: 
Returns: The mean 
Preconditions: None
Postconditions: None

*/


double calculate_deviation(double number, double mean) {

	double deviation; 

	deviation = number - mean; 

	return deviation; 

}
/*

Function: calculate_deviation 
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: uses the mean from calculate_mean function and subtracts it from a number to find the deviation 

Input Parameters: number, mean 
Returns: The deviation 
Preconditions: None
Postconditions: None

*/

double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5, int number) {

	double variance; 

	variance = ((deviation1 * deviation1) + (deviation2 * deviation2) + (deviation3 * deviation3) + (deviation4 * deviation4) + (deviation5)) / number;

	return variance; 

}
/*

Function: calculate_variance 
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: uses the deviation_function and multiplies each deviation number to the second power and divides it by a number to 
			 find the variance

Input Parameters: deviation1, deviation2, deviation3, deviation4, deviation5, number
Returns: The variance
Preconditions: None
Postconditions: None

*/
double calculate_standard_deviation (double variance) {

	double standardDeviation; 

	standardDeviation = sqrt(variance); 

	return standardDeviation; 
}

/*

Function: calculate_standard_deviation
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: uses the calulate_variance function to calculate the standard deviation of 5 numbers 
Input Parameters: variance
Returns: The standard deviation 
Preconditions: None
Postconditions: None

*/

double find_max(double number1, double number2, double number3, double number4, double number5){

	double max; 

	if(number1 > number2){

		max = number1;

	}
	else {

		max = number2; 

	}
	if (max < number3) {

		max = number3;

	}
	if (max < number4) {

		max = number4;
	}
	if (max < number5) {

		max = number5;
	}
	return max; 
}

/*

Function: find_max
Date Created: 02/07/24
Date Last Modified: 02/09/24

Description: compares 5 numbers using if and else statments to determine the biggest number

Input Parameters: double number1, double number2, double number3, double number4, double number5
Returns: The max
Preconditions: None
Postconditions: None

*/


double find_min(double number1, double number2, double number3, double number4, double number5) {

	double min; 
	
	if (number1 < number2) {

		min = number1;

	}
	else {

		min = number2;

	}
	if (min > number3) {

		min = number3;

	}
	if (min > number4) {

		min = number4;
	}
	if (min > number5) {

		min = number5;
	}
	return min;
}
/*

Function: find_min
Date Created: 02/07/24
Date Last Modified: 02/09/24

Description: compares 5 numbers using if and else statements to find the smallest number

Input Parameters: double number1, double number2, double number3, double number4, double number5
Returns: The min
Preconditions: None
Postconditions: None

*/

void print_double(FILE* output_stream, double number) {

	fprintf(output_stream, "%lf\n",number); 

	return 0; 
}


/*

Function: print_double
Date Created: 02/07/24
Date Last Modified: 02/07/24

Description: prints into the output file 

Input Parameters: output_stream, number
Returns: 0
Preconditions: None
Postconditions: None

*/