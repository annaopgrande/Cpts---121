#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include<math.h>
#define Pi = 3.14


double calculate_series_reisistance(r1, r2, r3);

double calculate_total_sales_tax(sales_tax_rate, item_cost);

double calculate_volume_pyramid(lengthOne, widthOne, heightOne);

double calculate_parallel_resistance(paralellR1, paralellR2, paralellR3);

double calculate_character_encode(encoded_character, plaintext_character, shift);

double calculate_distance_points(xOne, xTwo, yOne, yTwo);

double calculate_general_equation(generalY, generalZ, generalX, generalA);