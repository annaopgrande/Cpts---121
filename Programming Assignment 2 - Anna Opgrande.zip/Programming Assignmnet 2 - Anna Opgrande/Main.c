/*

		Name: Anna Opgrande 
		Date: 01/29/23 
		Class: CptS 
		Programming Assignment Two: Use functions and 3 different files 

*/
#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include<math.h>                                 // includes math.h to use the sqrt function 
#include"Equations.h"                           // includes header file that has the functions 

int r1 = 0, r2 = 0, r3 = 0, shift = 0, generalA = 0; 
double sales_tax_rate = 0, item_cost = 0, lengthOne = 0, widthOne = 0, heightOne = 0, paralellR1 = 0, paralellR2 = 0, paralellR3 = 0,
	xOne = 0, xTwo = 0, yOne = 0, yTwo = 0, generalY = 0, generalZ = 0, generalX = 0;
char plaintext_character, encoded_character;           // Reservers memory space for values 

int main(void){
	  

	//printf("Enter a value for resistance one to evaluate the series resistance: ");     // gets user imput for the resistance one 
	//scanf("%d",&r1);                                                                    // reads user imput and assigns it to r1 

	//printf("Enter a value for resistance two to evaluate the series resistance: ");      // gets user imput for resistance two 
	//scanf("%d",&r2);                                                                    // reads user imput and assigns it to r2 

	//printf("Enter a value for resistance three to evaluate the series resistance: ");  // gets user imput for resistance three 
	//scanf("%d",&r3);                                                                   // reads user imput and assigns it to r3 3

	//int seriesResistance = calculate_series_resistance(r1, r2, r3);                   // calls the calculate_series_resistance function 
	//printf("Series Resistance: %d\n",seriesResistance);                               // prints answer from the functions 

	//printf("Enter the sales tax: ");                                                   // gets user imput of the sales tax 
	//scanf("%lf",&sales_tax_rate);                                                      // reads sales tax and assigns it to sales_tax_rate 

 //   printf("Enter the item cost: ");                                                 // gets user imput for item cost 
	//scanf("%lf",&item_cost);                                                         // reads the cost and assigns it ot item_cost 

	//double salesTaxCost = calculate_total_sales_tax(sales_tax_rate, item_cost);       // calls the calculate_total_sales_tax 
	//printf("Sales tax Cost: %.3lf\n",salesTaxCost);                                  // prints result from funtion to the thousands place 

	//printf("Enter the length of the pyramid to find the volume: ");                  // prompts user for the length 
	//scanf("%lf",&lengthOne);                                                         // assigns imput to lengthOne 
	// 
	//printf("Enter the width of the pyramid to find the volume: ");                     // prompts user for width of pyramid 
	//scanf("%lf",&widthOne);                                                            // assigns the width to widthOne 

	//printf("Enter the height of the pyramid to find the volume: ");                   // prompts user for the height of the pyramid 
	//scanf("%lf",&heightOne);                                                          // assigns height to heightOne 
	//
	//double pyramidVolume = calculate_volume_pyramid(lengthOne, widthOne,heightOne);   // calls the function calculate_volume_pyramid 
	//printf("Pyramid Volume: %.3lf\n",pyramidVolume);                                  // prints the volume to the thousands place 

	//printf("Enter resistance one to calculate the paralell resistance:  ");           // prompts user for the resistance  
	//scanf("%lf",&paralellR1);                                                        // assigns resistance to paralellr1 

	//printf("Enter resistance two to calculate the paralell resistance: ");             // prompts user for a second resistance 
	//scanf("%lf",&paralellR2);                                                          // assigns resistance to paralellR2 

	//printf("Enter resistance three to calculate the paralell resistance: ");          // prompts user for a third resistance 
	//scanf("%lf",&paralellR3);                                                          // assigns resistance to paralellR3 

	//double paralellResistance = calculate_parallel_resistance(paralellR1,paralellR2,paralellR3);    // calls the function calculate_paralell_resistance 
	//printf("Paralell Resistance: %.3lf\n",paralellResistance);                                       // prints results from function to the thousands 

	////printf("Enter a character: ");                                                                 // prompts user for character 
	////scanf(" %c",&plaintext_character);                                                             // assigns character to plaintext_character 

	////printf("Enter a shift value: ");                                                                // prompts user for shift value integer 
	////scanf("%d\n",&shift);                                                                           // assigns value to shift 
	//// 
	////char characterEncoded = calculate_character_encode(encoded_character,plaintext_character,shift);    // calls calculate_character_encode 
	////printf("The encoded character is: %c\n ",characterEncoded);                                          // prints the value of 

	//printf("Enter the value of x one:");                                                       // prompts user for value of x 
	//scanf("%lf",&xOne);                      
	//// assigns value to xOne 

	//printf("Enter the value x two: ");                                                         // prompts user for second value of x 
	//scanf("%lf",&xTwo);                                                                        // assigns value to xTwo 

	//printf("Enter the value y one: ");                                                         // prompts user for value of y 
	//scanf("%lf",&yOne);                                                                        // assigns value to yOne 
	// 
	//printf("Enter the value y two: ");                                                           // prompts user for second y value 
	//scanf("%lf",&yTwo);                                                                         // assigns value to yTwo 

	//double distanceBetweenPoints = calculate_distance_points(xOne, xTwo, yOne, yTwo);          // calls distanceBetweenPoints functions 
	//printf("The distance between points: %.3lf\n ",distanceBetweenPoints);                     // prints output from the function 
	
	printf("Enter a value of A for the general equation: ");                                  // prompts user for value of A 
	scanf("%d", &generalA);                                                                   // assigns value to generalA

	printf("Enter a value of Y for the general equation: ");                                  // prompts user for value of Y 
	scanf("%lf", &generalY);                                                                   // assigns value to generalY 

	printf("Enter a value of X for the general equation: ");                                    // prompts user for value for of X 
	scanf("%lf", &generalX);                                                                    // assigns value to general X 

	printf("Enter a value of Z for the general equation: ");                                    // prompts user for value of z 
	scanf("%lf", &generalZ);                                                                     // prompts user for generalZ 

	double generalEquation = calculate_general_equation(generalY,generalZ, generalX, generalA);  // calls function calculate_general_equation 
	printf("General Equation = %lf",generalEquation);                                            // prints output from the function


	return 0; 
}