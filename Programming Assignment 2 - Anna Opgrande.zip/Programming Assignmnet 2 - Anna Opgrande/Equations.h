#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include<math.h>
#define PI 3.14 


int calculate_series_resistance(int r1,int r2,int r3) {
 
	int seriesResistance = 0;
	seriesResistance = r1 + r2 + r3;
	return seriesResistance;
}

/*

Function: calculate_series_resistance ()
Date created: 01/29/24
Last Modified: 02/2/24

Description: This function calculates the series resistance by adding the first, second and third resistance together. 

Input parameters: int r1,int r2,int r3
Returns: returns the series resistance.
Preconditions: 
Postconditions. 

*/
double calculate_total_sales_tax(double sales_tax_rate, double item_cost){

	double salesTaxCost = 0;
	salesTaxCost = sales_tax_rate * item_cost;
	return salesTaxCost;
}

/*
Function: calculate_total_sales_tax ()
Date created: 01/29/24
Last Modified: 02/2/24

Description: This function calculates the sales tax on an item. It takes the sales tax rate and the cost of the item and puts out the
			 cost of sales tax. 

Input parameters: double sales_tax_rate, double item_cost
Returns: return the sales tax cost
Preconditions: 
Postconditions: 
*/

double calculate_volume_pyramid(double lengthOne, double widthOne, double heightOne) {

	double pyramidVolume = 0; 
	pyramidVolume = lengthOne * widthOne * heightOne / 3; 
	return pyramidVolume; 
}
 
/*
Function: calculate_volume_pyramid()
Date Created: 01/29/24
Last Modified: 02/2/24

Description: This function calculates the volume of a pyramid based on its width, height and lenght of the pyramid. 

Input Parameters: None
Returns: returns the pyramid volume. 
Preconditions: 
Postconditions: 
*/

double calculate_parallel_resistance(double paralellR1, double paralellR2, double paralellR3) {

	double parallelResistance = 0;
	parallelResistance = 1 / (1 / paralellR1) + (1 / paralellR2) + (1 / paralellR3); 
	return parallelResistance; 

}
/*
Function: calculate_parallel_resistance()
Date Created: 01/29/24
Last Modified: 02/2/24

Descriptions: This function takes 3 different measurements of resistance and calculates the amount of paralell resistance. 

Input Parameters: double paralellR1, double paralellR, double paralellR3
Returns: returns the parallel resistance.
Precondtions:
Postconditions: 
*/

double calculate_character_encode(char encoded_character, char plaintext_character, int shift) {

	double characterEncoded = 0; 
	characterEncoded = (plaintext_character - 'a') + 'A' - shift; 
	return characterEncoded; 

}
/*
Function: calculate_characer_encode()
Date Created: 01/29/24
Last Modified: 02/24/24

Description: Takes a characeter and plugs it into the equation and gives the ASCII equivalent character. 

Input Parameters: char encoded_character, char plaintext_character, int shift
Returns: returns the encoded character 
Precondtions: 
Postconditions: 
*/

double calculate_distance_points(double xOne, double xTwo, double yOne, double yTwo) {

	double distanceBetweenPoints = 0; 
	distanceBetweenPoints = sqrt(((xOne - xTwo) * (xOne - xTwo)) + (((yOne - yTwo) * (yOne - yTwo))));
	return distanceBetweenPoints; 
}
/*
Function: calculate_dostance_points()
Date Created: 01/29/24
Last Modified: 02/24/24

Description: Takes 2 points and puts out the distance between the points 

Input Parameters: double xOne = 0, double xTwo = 0, double yOne = 0, double yTwo = 0
Returns: returns the distance between points 
Preconditions: 
Postconditions: 
*/


double calculate_general_equation(double generalY, double generalZ, double generalX, int generalA) {

	double generalEquation = 0;
	generalEquation = generalY / ((3/17) - generalZ + generalX) / ((generalA % 2) * 3.14); 
	return generalEquation; 
}

/*
Function: calculate_general_equation()
Date Created: 01/29/24
Last Modified: 02/2/24

Description: Takes values for x, y,z and a ans plugs them into the general equation. Puts out the answer to the equatation. 

Input Parameters: double generalY, double generalZ, double generalX, int generalA
Returns: returns the distance between points 
Precondtions:
Postconditions: 
*/

