
#define _CRT_SECURE_NO_WARNINGS_ 
#include <stdio.h>

void printGameRules(); 

double getBankBalance(); 

double getWagerAmount();

double checkWagerAmount(double wager, double balance); 

int rollADice();

int calculateSumofDie(int dieOneValue, int dieTwoValue);

int isWinLossOrPoint(int sumDie);

int isPointLossOrNeither(int sumDie, int pointValue); 

double adjustBankBalance(double bankBalance, double wagerAmount, int addOrSubtract);

void chatterMessages(int numberRolls, int winLossNeither, double initialBankBalance, double currentBankBalance); 