/*

		Name: Anna Opgrande 
		Date: 02/20/24
		Class: CptS 121 
		Assignment: Assignmnent 3, "Craps"
		
		This program runs a game of "Craps". It will display the rules along with other messages. It will also take and stores amount wages 
		and "roll dice" by generating random numbers from 1 to 12. The programm will display whether or not the player one and their wage by 
		end of the game. 
*/

#define _CRT_SECURE_NO_WARNINGS_ 
#include <stdio.h>
#include "Functions.h"

int main(){

	void printGameRules(); 



	return 0; 
}