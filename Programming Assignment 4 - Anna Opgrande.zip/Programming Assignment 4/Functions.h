
#define _CRT_SECURE_NO_WARNINGS_ 
#include <stdio.h>

void printGameRules(){

	printf("The player will roll two dice with 6 faces each.");
	printf("The faces facing upward after the roll will added together.");
	printf("If the sum is 7 or 11 the player wins."); 
	printf("If the sum is 2 3 or 12, the player loses."); 
	printf("If the sum is 4,5,6,8,9 or 10 the sum becomes the players point."); 
	printf("The player will then continue to roll dice to make their point, if a 7 is rolled before the point is made then the player loses."); 

	return 0;
}

double getBankBalance();

double getWagerAmount();

double checkWagerAmount(double wager, double balance);

int rollADice();

int calculateSumofDie(int dieOneValue, int dieTwoValue);

int isWinLossOrPoint(int sumDie);

int isPointLossOrNeither(int sumDie, int pointValue);

double adjustBankBalance(double bankBalance, double wagerAmount, int addOrSubtract);

void chatterMessages(int numberRolls, int winLossNeither, double initialBankBalance, double currentBankBalance);